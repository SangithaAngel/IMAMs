<?php
ob_start();
include 'conn.php';
session_start();
if(isset($_POST['submit'])){
    $id=$_SESSION['idadmin'];
	$name=$_POST['name'];
	$fname=$_POST['fname'];
	$Email=$_POST['Email'];
	$cno=$_POST['cno'];
	$ads=$_POST['ads'];
	$branch=$_POST['branch'];  
	$rank=$_POST['rank'];     
	
	if(isset($_FILES['image']))
	{
		 if(!empty($_FILES['image']['name']))
		 {
			$file_name = $_FILES['image']['name'];
			$file_size =$_FILES['image']['size'];
			$file_tmp =$_FILES['image']['tmp_name'];
			$file_type=$_FILES['image']['type'];
			$file_ext=explode('.',$file_name);
			$file_ext=strtolower(end($file_ext));
			$destination="../admin/upload/";
		    if(($file_ext=='jpg')||($file_ext=='jpeg')||($file_ext=='png'))
		   {
			    $img=uniqid().$file_name;
			    move_uploaded_file($file_tmp, $destination.$img); 
			    
		   }else{
			$img='';
		   }
		 }
		 $sql= "UPDATE trainer SET img='$img',name='$name' ,fname='$fname',email_id ='$Email',contct_number='$cno',adds='$ads',branch='$branch',rank='$rank' WHERE id='$id'"; mysqli_query($conn,$sql) or die(mysqli_error());
	}
	$sql1= "UPDATE trainer SET name='$name' ,fname='$fname',email_id ='$Email',contct_number='$cno',adds='$ads',branch='$branch',rank='$rank' WHERE id='$id'"; mysqli_query($conn,$sql1) or die(mysqli_error());
	 
   header("location:profile.php");  
ob_flush();   
}
?>  