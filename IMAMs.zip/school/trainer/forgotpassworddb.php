<?php
include 'conn.php'; 
if(isset($_POST['submit']))
{
    $s="SELECT * FROM  trainer where email_id='".$_POST['email']."'";   
//echo $s;
$a=mysqli_query($conn,$s);
$n=mysqli_num_rows($a);

if($n>0)
{
	$r=mysqli_fetch_array($a);
 	$email=$r['email_id'];
	$username=$r['name'];
	$password=$r['pass'];
	$subject= "Reset Password ";
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";        
    $contactMessage =  
	"<div>
	<p><strong>Dear $username,</strong></p>
	<br/>
	<p><strong>Reset Password </strong></p>
	<br/>
	<p>
	<strong>User Email:</strong>$email <br/>
	<strong>Password:</strong>$password 
	</p>
	<br/>
	<p><strong>Thanks & Regards</strong></p><br/>
	<p><strong>Team SSG</strong></p><br/>
	</div>";
        
$response = (mail($email,$subject,$contactMessage,$headers) ) ? 
"success" : "failure" ;
	//$output = json_encode(array("response" => $response));
	header("location:forgot-password.php?msg=1");
}
else
{        
	 header("location:forgot-password.php?msg=0");
}
}

?>