<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
	$tid=$_SESSION['idadmin'];
	$branch=$_POST['branch']; 
	$date=$_POST['date']; 
	$stime=$_POST['stime']; 
	$etime=$_POST['etime']; 



		$sql1= "INSERT INTO tr_attandance (tid,branch,startdate,enddate,date)VALUES('$tid','$branch','$stime','$etime','$date')";        
	    $res1= mysqli_query($conn,$sql1);
		//echo("Errorcode: " . mysqli_errno($conn));
		if ($res1){ 
			header('location:create-session.php?msg=2');
		}else{
			header('location:create-session.php?msg=1');
		}
	    
	//}
    }
}
?>