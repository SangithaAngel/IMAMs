<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
	    $message=$_POST['message']; 
	    $userid=$_SESSION['idadmin']; 
	    $usertype='trainer'; 
		$sql1="INSERT INTO forum (userid,usertype,description)VALUES('$userid','$usertype','$message')";                
	    $res1= mysqli_query($conn,$sql1);
		if ($res1){ 
			header('location:add-message.php?msg=2');
		}else{
			header('location:add-message.php?msg=1');  
		}
    }
}
?>