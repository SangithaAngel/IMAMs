<!DOCTYPE html>
<html lang="en">
<head>
<title>Trainer Panel | Sign In</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="expires" content="Thu, 19 Nov 1900 08:52:00 GMT">
<!--Loading bootstrap css-->
<link type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,800italic,400,700,800">
<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
<link type="text/css" rel="stylesheet" href="css/jquery-ui-1.10.3.custom.css">
<link type="text/css" rel="stylesheet" href="css/font-awesome.min.css">
<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">

<link rel="shortcut icon" type="image/ico" href="images/favicon.ico"/>

<!--Loading style vendors-->
<link type="text/css" rel="stylesheet" href="css/animate.css">
<link type="text/css" rel="stylesheet" href="css/all.css">

<!--Loading style-->
<link type="text/css" rel="stylesheet" href="css/custom.css" class="default-style">


<link type="text/css" rel="stylesheet" href="css/style-responsive.css">

<!-- invisible message S-->
<script type="text/javascript" src="js1/jquery-latest.js"></script>
    <script type="text/javascript"> 
      $(document).ready( function() {
        $('#deletesuccess').delay(4000).fadeOut();
      });
    </script>
<!-- invisible message E-->

</head>
 <center><img  src="images/logo.jpg" width="150px" height="150px"></center>
<body id="signin-page">
  <div class="page-form">
     <form method="post" action="signindb.php" class="form">
	 
	   <div class="header-content">
	    <h4 align="center" style="color:#FF0000"></h4>
					<h1>Log In</h1>
	   </div>
	   
	   <div class="body-content">
		<div class="form-group">
		 <div class="input-icon right"><i class="fa fa-user"></i>
	<input type="text" placeholder="Enter email" name="uemail" required class="form-control">
	     </div>
		</div>
		<div class="form-group">
		  <div class="input-icon right"><i class="fa fa-key"></i><input type="password" placeholder="Password" name="password" required class="form-control"></div>
		 </div>
		 
		 <div class="form-group pull-right">
		    <button type="submit" name="submit" class="btn btn-success">Log In&nbsp;<i class="fa fa-chevron-circle-right"></i></button>
		 </div>
		 
		  <div class="form-group pull-left">
		  
		  <?php if(isset($_GET['msg']))
					{ 
					?>
					<div id="deletesuccess" style="font-size:14px; color:#AF2822;"><strong>Wrong Email Or Password</strong> </div>
					 <?php 
					 }
					 ?>
		<?php
		       if(isset($_GET['msg1'])==1)
		       { ?>
		        <div id="deletesuccess" style="font-size:14px; color:#AF2822;"><strong>Send Your Password in Registered Mail Id</strong> </div><?php }
		?>			 
		 </div>
		 
		 <div class="clearfix"></div>
		 <div class="forget-password">
		    <h4><a href='forgot-password.php' class='btn-forgot-pwd'>Forgot Password?</a></h4>
		</div>
	</div>
	
	</form>
</div>

<script src="js/jquery-1.10.2.min.js"></script>
<script src="js/jquery-migrate-1.2.1.min.js"></script>
<script src="js/jquery-ui.js"></script>
<!--loading bootstrap js-->
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-hover-dropdown.js"></script>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<script src="js/icheck.min.js"></script>
<script src="js/custom.min.js"></script>
<script>//BEGIN CHECKBOX & RADIO
$('input[type="checkbox"]').iCheck({
    checkboxClass: 'icheckbox_minimal-grey',
    increaseArea: '20%' // optional
});
$('input[type="radio"]').iCheck({
    radioClass: 'iradio_minimal-grey',
    increaseArea: '20%' // optional
});
//END CHECKBOX & RADIO</script>
</body></html>