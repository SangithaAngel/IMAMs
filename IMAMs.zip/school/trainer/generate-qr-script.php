<?php
session_start();
include "conn.php";
include "phpqrcode/qrlib.php";
if (isset($_POST['generateQr']) == 'generateQr')
{
    $branch = $_POST['branch']; // receive the text for QR
    $date = $_POST['date']; // receive the text for QR
    $stime = $_POST['stime']; // receive the text for QR
    $etime = $_POST['etime']; // receive the text for QR
    $rank = $_POST['rank']; // receive the text for QR 
	$tid=$_SESSION['idadmin'];
	
	$qrText="Branch :".$branch." Rank :".$rank ." Date : ".$date."  Start Date ".$stime." End Date ".$etime; 
    $directory = "generated-qr/"; 
    $fileName = 'QR-'.rand().'.png'; 
    QRcode::png($qrText, $directory.$fileName, 'L', 4, 2);   
	$qrimage=$directory.$fileName; 
	$sql1= "INSERT INTO tr_attandance (tid,branch,rank,startdate,enddate,date,qrimage)VALUES('$tid','$branch','$rank','$stime','$etime','$date','$qrimage')";          
    mysqli_query($conn,$sql1);      

    echo "success^".$directory.$fileName; // returns the qr-image path */
}