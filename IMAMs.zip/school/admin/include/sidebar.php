<?php
include('conn.php');
	 $id=$_SESSION['idadmin'];
?>
 <nav id="sidebar" role="navigation" class="navbar-default navbar-static-side noprint">
        <div class="sidebar-collapse menu-scroll">
            <ul id="side-menu" class="nav">
                <li class="user-panel">
                    <div class="thumb">
                        <?php
                        $sqll="select * from admin where id='".$id."'";
                        $resultl=mysqli_query($conn,$sqll);
                        $rowl=mysqli_fetch_array($resultl);
						if(isset($rowl['img']))
						{ $image=$rowl['img'];  
						}else{
							$image='';  
						}
                        if($image!='') {
                        ?>
                        <img src="upload/<?php echo $rowl['image']; ?>" alt="Profile" class="img-circle">
                        <?php } else { ?>
                         <img src="images/profile.jpg" alt="Profile" class="img-circle"/>
                        <?php } ?>
                    </div>
                    <div class="info"><p><?php  echo $rowl['username'];?></p>
                        <ul class="list-inline list-unstyled">
                            <li><a href="profile.php" data-hover="tooltip" title="Profile"><i class="fa fa-user"></i></a></li>
                            <li><a href="logout.php" data-hover="tooltip" title="Logout"><i class="fa fa-sign-out"></i></a></li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                </li>
				<li>
                    <a href="profile.php"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title">Profile</span>
                    </a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title">Student</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="add-student.php"><span class="submenu-title">Add student</span></a></li>
                        <li><a href="manage-students.php"><span class="submenu-title">Manage student</span></a></li> 
                    </ul>
                </li>

                <li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title">Trainer</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="add-trainer.php"><span class="submenu-title">Add Trainer</span></a></li>
                        <li><a href="manage-trainer.php"><span class="submenu-title">Manage Trainer</span></a></li> 
                    </ul>  
                </li>
				<li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title">Attendance</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="view-student-att.php"><span class="submenu-title">View Student Attendance</span></a></li>
						 <li><a href="view-trainer-att.php"><span class="submenu-title">View Trainer Attendance</span></a></li>
                    </ul>
                </li>
				<li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title">Merchandise</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="add-product.php"><span class="submenu-title">Add Merchandise</span></a></li>
                        <li><a href="manage-product.php"><span class="submenu-title">Manage Merchandise</span></a></li>
						 <li><a href="manage-orders.php"><span class="submenu-title">Manage Orders</span></a></li>
                    </ul>
                </li>
				<li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title">Add Fees</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="add-fees.php"><span class="submenu-title">Add Fees</span></a></li>
                        <li><a href="manage-fees1.php"><span class="submenu-title">Manage Fees</span></a></li>
                    </ul>
                </li>
                
                	<li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title">Schedule</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="add-schedule.php"><span class="submenu-title">Add Schedule</span></a></li>
                        <li><a href="manage-schedule.php"><span class="submenu-title">Manage Schedule</span></a></li>
                    </ul>
                </li>
                
                
                
                
                <li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title">Communication</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="add-message.php"><span class="submenu-title">Add Message</span></a></li>
                        <li><a href="manage-message.php"><span class="submenu-title">View & Manage Message</span></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>  