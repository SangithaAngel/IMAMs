<div id="footer" class="noprint">
<div class="copyright">2021 &copy; IMMORTAL MARTIAL ARTS MANAGEMENT SYSTEM</div>
</div>