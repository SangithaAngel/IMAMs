<?php
include('conn.php');
error_reporting('E_ALL');
?>
<div id="header-topbar-option-demo" class="page-header-topbar noprint">
<nav id="topbar" role="navigation" style="margin-bottom: 0; z-index: 2;" class="navbar navbar-default navbar-static-top">

<div class="navbar-header">
<button type="button" data-toggle="collapse" data-target=".sidebar-collapse" class="navbar-toggle"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>

<a id="logo" href="profile.php" style="margin-top:-10px;" class="navbar-brand"><span class="fa fa-rocket"></span><span class="logo-text"><h3 style="margin-top:10px !important; margin-bottom: -10px;" >
<img src="images/logo.jpg" width="60px" height="60px">
<strong>IMAMS </strong></h3><span style="font-size:10px"> </span></span><span style="display: none" class="logo-text-icon"></span></a>
</div>


<div class="topbar-main"><a id="menu-toggle" href="#" class="hidden-xs"><i class="fa fa-bars"></i></a>
    <ul class="nav navbar-nav   horizontal-menu hidden-sm hidden-xs">
	  <li><a href="profile.php"><i class="fa fa-file-text"></i>&nbsp;  Reminder</a></li>
	</ul>
	
	
	<ul class="nav navbar navbar-top-links navbar-right mbn">
	  
		<li class="dropdown topbar-user"><a data-hover="dropdown" href="#" class="dropdown-toggle"><img src="images/profile.jpg" alt="" class="img-responsive img-circle"/>&nbsp;<span class="hidden-xs"><?php  //echo $_SESSION['name']?></span>&nbsp;<span class="caret"></span></a>
		<ul class="dropdown-menu dropdown-user pull-right">
		 
		 <li><a href="change-password.php"><i class="fa fa-pencil-square-o fa-fw"><div class="icon-bg bg-green"></div></i>Change Password</a></li>
		
		 <li><a href="logout.php"><i class="fa fa-key"></i>Log Out</a></li>
		</ul>
	  </li>
	</ul>
	<br><br/> 
</div>


</nav>
	 
	  
 </div>
 <style>
 .btn-blue-c{
	background:blue !important; 
	color:white; 
}
.btn-green-c{
	background:green !important; 
	color:white; 
}
.btn-red-c{
	background:red !important; 
	color:white; 
}
 </style>