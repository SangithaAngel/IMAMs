<?php
if(isset($_POST['usrpass']) && $_POST['token'] && $_POST['email'])
{
include "conn.php";
$emailId = $_POST['email'];
$token = $_POST['token'];
$password = md5($_POST['usrpass']);
$query = mysqli_query($conn,"SELECT * FROM admin WHERE usrpass='".$token."' and `email`='".$emailId."'");
$row = mysqli_num_rows($query);
if($row){
mysqli_query($conn,"UPDATE users set  usrpass='" . $password . "', token='" . NULL . "' WHERE email='" . $emailId . "'");
echo '<p>Congratulations! Your password has been updated successfully.</p>';
}else{
echo "<p>Something goes wrong. Please try again</p>";
}
}
?>