<?php
session_start();
error_reporting('E_ALL');   
include "conn.php";
	$idcardno = $_POST['idcardno']; 
	$sql1 = "select * from student where icno='$idcardno'"; 
	$result1 = mysqli_query($conn,$sql1);
	if(mysqli_num_rows($result1)>1)
	{ echo "false";          
	}else{ $row1=mysqli_fetch_array($result1);	
		   echo json_encode($row1); 
		   
	}
	
?>