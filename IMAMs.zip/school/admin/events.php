<?php
session_start();
include "conn.php";
error_reporting();
if(isset($_SESSION['idadmin'])) 
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel</title>    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="">
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="images/favicon.png">

    <!--Loading bootstrap css-->
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="css/jquery-ui-1.10.4.custom.min.css">
    <link type="text/css" rel="stylesheet" href="css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">

    <!--LOADING STYLESHEET FOR PAGE-->
    <link type="text/css" rel="stylesheet" href="css/colorpicker.css">
    <link type="text/css" rel="stylesheet" href="css/datepicker.css">
    <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap-timepicker.min.css">
    <link type="text/css" rel="stylesheet" href="css/clockface.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap-switch.css">
    <link href="css/style-review.css" rel="stylesheet" type="text/css" />
    <link type="text/css" rel="stylesheet" href="css/bootstrap3-wysihtml5.min.css">

    <!--Loading style vendors-->
    <link type="text/css" rel="stylesheet" href="css/animate.css">
    <link type="text/css" rel="stylesheet" href="css/pace.css">
    <link type="text/css" rel="stylesheet" href="css/all.css">
    <link type="text/css" rel="stylesheet" href="css/jquery.notific8.min.css">
    <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">
	<link href='css/select2.css' rel='stylesheet' type='text/css'>
        <link href='css/cal.css' rel='stylesheet' type='text/css'>
    <!--Loading style-->
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" class="default-style">
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" id="theme-change" class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="css/style-responsive.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <style>
	input[type='radio']{
	    opacity: 1 !important;
	    width: 150% !important;
	    height: 15px !important;
	    margin: 4px 0px !important;
	}     
    </style>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script> -->
</head>
<body class=" ">
    <a id="totop" href="#"><i class="fa fa-angle-up"></i></a>
    <?php include'include/header.php' ?>
    <div id="wrapper">
	<!--BEGIN SIDEBAR MENU-->
	<?php include'include/sidebar.php' ?>
	<!--END SIDEBAR MENU-->
	<!--BEGIN PAGE WRAPPER-->
	<div id="page-wrapper">
	    <!--BEGIN TITLE & BREADCRUMB PAGE-->
	    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
		<!--<div class="page-header pull-left"><div class="page-title">Publish News</div></div>-->
		<ol class="breadcrumb page-breadcrumb pull-left">
                    <li class="active"><i class="fa fa-home"></i>&nbsp;<a href="events.php">Event > Add Event</a></li>
		</ol>
		<div class="btn btn-blue reportrange"><i class="fa fa-calendar"></i>&nbsp;<span></span></div>
		<div class="clearfix"></div>
	    </div>
 <div class="page-content">
                    <div id="table-action" class="row">
                        <div class="col-lg-12">
                            <div id="tableactionTabContent" class="tab-content">
                                <div id="pp" class="tab-pane fade in active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="panel panel-blue">
                                               <div class="panel-heading">Event</div>
                                               <div class="panel-body">
                                                    <tbody>

    <!-- (A) JS + CSS -->
  
    <script>
 
    var cal = {
  // (A) SUPPORT FUNCTION - AJAX CALL
  ajax : function (data, load) {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "eve.php");
    if (load) { xhr.onload = load; }
    xhr.send(data);
  },

  // (B) ON PAGE LOAD - ATTACH LISTENERS + DRAW
  init : function () {
    document.getElementById("calmonth").addEventListener("change", cal.draw);
    document.getElementById("calyear").addEventListener("change", cal.draw);
    document.getElementById("calformdel").addEventListener("click", cal.del);
    document.getElementById("calform").addEventListener("submit", cal.save);
    document.getElementById("calformcx").addEventListener("click", cal.hide);
    cal.draw();
  },

  // (C) DRAW CALENDAR
  draw : function () {
    // (C1) FORM DATA
    let data = new FormData();
    data.append("req", "draw");
    data.append("month", document.getElementById("calmonth").value);
    data.append("year", document.getElementById("calyear").value);

    // (C2) ATTACH CLICK TO UPDATE EVENT ON AJAX LOAD
    cal.ajax(data, function(){
      let wrapper = document.getElementById("calwrap");
      wrapper.innerHTML = this.response;
      let all = wrapper.getElementsByClassName('day');
      for (let day of all) {
        day.addEventListener("click", cal.show);
      }
      all = wrapper.getElementsByClassName('calevt');
      if (all.length != 0) { for (let evt of all) {
        evt.addEventListener("click", cal.show);
      }}
    });
  },
  
  // (D) SHOW EVENT DOCKET
  show : function (evt) {
    let eid = this.getAttribute("data-eid");
    // (D1) ADD NEW EVENT
    if (eid === null) {
      let year = document.getElementById("calyear").value,
          month = document.getElementById("calmonth").value,
          day = this.dataset.day;
      if (month.length==1) { month = "0" + month; }
      if (day.length==1) { day = "0" + day; }
      document.getElementById("calform").reset();
      document.getElementById("evtid").value = "";
      document.getElementById("evtstart").value = `${year}-${month}-${day}`;
      document.getElementById("evtend").value = `${year}-${month}-${day}`;
      document.getElementById("calformdel").style.display = "none";
    }

    // (D2) EDIT EVENT
    else {
      let edata = JSON.parse(document.getElementById("evt"+eid).innerHTML);
      document.getElementById("evtid").value = eid;
      document.getElementById("evtstart").value = edata['evt_start'];
      document.getElementById("evtend").value = edata['evt_end'];
      document.getElementById("evttxt").value = edata['evt_text'];
      document.getElementById("evtcolor").value = edata['evt_color'];
      document.getElementById("calformdel").style.display = "block";
    }

    // (D3) SHOW DOCKET
    document.getElementById("calblock").classList.add("show");
    evt.stopPropagation();
  },
  
  // (E) HIDE EVENT DOCKET
  hide : function () {
    document.getElementById("calblock").classList.remove("show");
  },
  
  // (F) SAVE EVENT
  save : function (evt) {
    // (F1) FORM DATA
    let data = new FormData(),
        eid = document.getElementById("evtid").value;
    data.append("req", "save");
    data.append("start", document.getElementById("evtstart").value);
    data.append("end", document.getElementById("evtend").value);
    data.append("txt", document.getElementById("evttxt").value);
    data.append("color", document.getElementById("evtcolor").value);
    if (eid!="") { data.append("eid", eid); }

    // (F2) AJAX SAVE
    cal.ajax(data, function(){
      if (this.response=="OK") { cal.hide(); cal.draw(); }
      else { alert(this.response); }
    });
    evt.preventDefault();
  },

  // (G) DELETE EVENT
  del : function () { if (confirm("Delete Event?")) {
    // (G1) FORM DATA
    let data = new FormData();
    data.append("req", "del");
    data.append("eid", document.getElementById("evtid").value);
    
    // (G2) AJAX DELETE
    cal.ajax(data, function(){
      if (this.response=="OK") { cal.hide(); cal.draw(); }
      else { alert(this.response); }
    });
  }}
};
window.addEventListener("DOMContentLoaded", cal.init);
    
    
    </script>
  </head>
<br>
  <body>
    <!-- (B) PERIOD SELECTOR -->
    <div id="calPeriod"><?php
      // (B1) MONTH SELECTOR
      // NOTE: DEFAULT TO CURRENT SERVER MONTH YEAR
      $months = [
        1 => "January", 2 => "Febuary", 3 => "March", 4 => "April",
        5 => "May", 6 => "June", 7 => "July", 8 => "August",
        9 => "September", 10 => "October", 11 => "November", 12 => "December"
      ];
      $monthNow = date("m");
      echo "<select id='calmonth'>";
      foreach ($months as $m=>$mth) {
        printf("<option value='%s'%s>%s</option>", 
          $m, $m==$monthNow?" selected":"", $mth
        );
      }
      echo "</select>";

      // (B2) YEAR SELECTOR
      echo "<input type='number' id='calyear' value='".date("Y")."'/>";
    ?></div>

    <br>
    <br>
    <!-- (C) CALENDAR WRAPPER -->
    <div id="calwrap"></div>

    <!-- (D) EVENT FORM -->
    <div id="calblock"><form id="calform">
      <input type="hidden" id="evtid"/>  
      <label for="start">Date Start</label>
      <input type="date" id="evtstart" required/>
      <label for="end">Date End</label>
      <input type="date" id="evtend" required/>
      <label for="txt">Event</label>
      <textarea id="evttxt" required></textarea>
      <label for="color">Color</label>
      <input type="color" id="evtcolor" required/>
      <input type="submit" id="calformsave" value="Save"/>
      <input type="button" id="calformdel" value="Delete"/>
      <input type="button" id="calformcx" value="Cancel"/>
    </form></div>
  </body>


</head>

</html>


       </tbody>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--END CONTENT-->
                    </div>



    <?php include'include/footer.php'?>
    </div>
    <script>
      $.validate({
	lang: 'es'
      });
    </script>

    <!--<script src="js/jquery-1.10.2.min.js"></script>-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/jquery-ui.js"></script><!--loading bootstrap js-->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="js/jquery.metisMenu.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/icheck.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/jquery.notific8.min.js"></script>
    <script src="js/highcharts.js"></script>
    <script src="js/jquery.menu.js"></script>
    <script src="js/pace.min.js"></script>
    <script src="js/holder.js"></script>
    <script src="js/responsive-tabs.js"></script>
    <script src="js/jquery.newsTicker.min.js"></script>
    <script src="js/moment.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/daterangepicker.js"></script>
	<script src='js/select2.js' type='text/javascript'></script>
    <!--CORE JAVASCRIPT-->
    <script src="js/main.js"></script>

</body>
</html>
<?php  
}  
else
{
    header("location:index.php");
}
?>
   