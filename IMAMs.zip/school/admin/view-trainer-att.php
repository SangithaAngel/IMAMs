<?php
session_start();
include "conn.php";
if(isset($_SESSION['idadmin']))
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="">
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <!--Loading bootstrap css-->
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="css/jquery-ui-1.10.4.custom.min.css">
    <link type="text/css" rel="stylesheet" href="css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">

    <!--LOADING STYLESHEET FOR PAGE-->
    <link type="text/css" rel="stylesheet" href="css/jquery.dataTables.css">
    <link type="text/css" rel="stylesheet" href="css/dataTables.tableTools.min.css">
    <link type="text/css" rel="stylesheet" href="css/dataTables.bootstrap.css">



    <!--Loading style vendors-->
    <link type="text/css" rel="stylesheet" href="css/animate.css">
    <link type="text/css" rel="stylesheet" href="css/pace.css">
    <link type="text/css" rel="stylesheet" href="css/all.css">
    <link type="text/css" rel="stylesheet" href="css/jquery.notific8.min.css">
    <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">

    <!--Loading style-->
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" class="default-style">
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" id="theme-change" class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="css/style-responsive.css">
    <style>
	.table select option {
		color: #000;
	}
	@media print
         {
         .noprint {display:none;}
         #print{display:inline-table!important; display:block!important;}
         }
         input[type='radio']{
         opacity: 1 !important;
         width: 150% !important;
         height: 15px !important;
         margin: 4px 0px !important;
         }     
	
	.print-only{
        display: none;
    }

    @media print {
        .no-print {
            display: none;
        }

        .print-only{
            display: block;
        }
}

    </style>
</head>
<body class="">
    <!--BEGIN BACK TO TOP-->
    <a class="noprint" id="totop" href="#"><i class="fa fa-angle-up"></i></a>
    <!--END BACK TO TOP-->
    <!--BEGIN TOPBAR-->
    <?php 
    include'include/header.php';
    ?>
    <!--END TOPBAR-->
    <div id="wrapper">
    <!--BEGIN SIDEBAR MENU-->
	<?php include'include/sidebar.php'; ?>
	<!--END SIDEBAR MENU-->
	<!--BEGIN PAGE WRAPPER-->
	<div id="page-wrapper">
	    <!--BEGIN TITLE & BREADCRUMB PAGE-->
	    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb noprint">
		<ol class="breadcrumb page-breadcrumb pull-left">
                    <li><i class="fa fa-home"></i>&nbsp;<a href="view-trainer-att.php">Trainer</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
		       <li class="hidden"><a href="#">Dashboard</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
		       <li class="active">View Trainer Attendance </li>
		    </ol>
		      <a href="events.php"> <div class="btn btn-blue reportrange"><i class="fa fa-calendar"></i>&nbsp;<span></span></div></a>
		    <div class="clearfix"></div>
	    </div>
	    <!--END TITLE & BREADCRUMB PAGE-->
	    <!--BEGIN CONTENT-->
	    <div class="page-content">
		<div class="row">
		    <div class="col-lg-12">
			<div class="table-responsive">
			    <?php 
			    if(isset($_GET['msg']))
			    {

				 if($_GET['msg']==1)
				{ 
				?>
				<div class="panel-heading">
				    <h2  align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Deleted Sucessfully</h2>
				</div> 
				<?php
				 }
			      }
			      ?>
                <button class="button button2" id="print_ntn">Print</button>
				<button class="button button2" id="excel_ntn">Excel</button>
				<button class="button button2" id="pdf_ntn">Pdf</button>
			    <table id="table_id" class="table table-hover table-striped table-bordered table-advanced tablesorter display">
				<thead>
				    <tr>
						<th>Id</th>
						<th>Name</th>
						<th>Branch</th>
						<th>Rank</th>
						<th>Date</th>
						<th>Time</th>
						<!--<th>Action</th>-->
				    </tr>
				</thead>
				<tbody>
				<?php  
				
		
				$sql1="select * from  tr_attandance";  
				$result=mysqli_query($conn,$sql1);
				$n=1;
				while($row=mysqli_fetch_array($result))
				{ $id=$row['tid'];
        		  $sql="SELECT * FROM trainer WHERE id='$id'";
				  $result1=mysqli_query($conn,$sql);
				  $row1=mysqli_fetch_assoc($result1);
				  $name=$row1['name'];
				?>
				<tr>
				  <th><?php echo $row['id'];?></th>
				  <td><?php echo $name;?></td>
				  <td><?php echo $row['branch'];?></td>
				  <td><?php echo $row['rank'];?></td>
				  <td><?php echo $row['date'];?></td>
				  <td>From:<?php echo $row['startdate'];?> To <?php echo $row['enddate'];?></td>
			<!--
				  <td class="noprint">
					
					<a href="edit-message.php?id=<?php echo $row['id'];?>"><button type="button" class="btn btn-blue btn-xs"><i class="fa fa-edit"></i>&nbsp;Edit</button></a>				
 					
				   </td>-->
				</tr> 
				<?php  
				    $n++; 
				}
				?>
				</tbody>
			    </table>
			</div>
		    </div>
		</div>
	    </div> 
	    <!--END CONTENT-->

	</div>
	<!--END PAGE WRAPPER-->

    <!--BEGIN FOOTER-->
    <?php include'include/footer.php'; ?>
    <!--END FOOTER-->

    <!--END  WRAPPER-->
    </div>
    <!--<script src="js/jquery-1.10.2.min.js"></script>-->
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/jquery-ui.js"></script><!--loading bootstrap js-->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="js/jquery.metisMenu.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/icheck.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/jquery.notific8.min.js"></script>
    <script src="js/highcharts.js"></script>
    <script src="js/jquery.menu.js"></script>
    <script src="js/pace.min.js"></script>
    <script src="js/holder.js"></script>
    <script src="js/responsive-tabs.js"></script>
    <script src="js/jquery.newsTicker.min.js"></script>
    <script src="js/moment.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/daterangepicker.js"></script>
    <!--CORE JAVASCRIPT-->
    <script src="js/main.js"></script>
    <!--LOADING SCRIPTS FOR PAGE-->
    <script src="js/jquery.dataTables.js"></script>
    <script src="js/dataTables.bootstrap.js"></script>
    <!--<script src="js/dataTables.tableTools.min.js"></script>-->
    <script src="js/table-datatables1.js"></script>
    <script src="js/table2excel.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
	<script src="js/filterDropDown.js"></script>
    <script> 
	$(document).ready(function() {
       $('#table_id').dataTable( {
	   //"order": [[ 0, "desc" ]]
	   buttons: [
			{
				extend: 'copy',
				text: 'Copy to clipboard'
			},
			'excel',
			'pdf'
		], 
		filterDropDown: {										
						columns: [
						    { 
								idx: 1
							},
							{ 
								idx: 2
							},
							{ 
								idx: 4
							},
							{ 
								idx: 5
							}
						],
						bootstrap: true
					}
       } );  
	   
	$('#print_ntn').on('click',function(){
	printData();
	});
	var doc = new jsPDF();
	var specialElementHandlers = {
		'#editor': function (element, renderer) {
			return true;
		}
	};

	$('#pdf_ntn').click(function () {   
		doc.fromHTML($('#table_id').html(), 15, 15, {
			'width': 170,
				'elementHandlers': specialElementHandlers
		});
		doc.save('sample-file.pdf');
	});
			$("#excel_ntn").click(function () {
                $("#table_id").table2excel({
                    filename: "Table1.xls"
                });
            }); 
    } );
	function printData(){
	   var divToPrint=document.getElementById("table_id");
	   newWin= window.open("");
	   newWin.document.write(divToPrint.outerHTML);
	   newWin.print();
	   newWin.close();
	}
	</script>
</body>
</html>
<?php 
}
else
{
header("location:index.php");
}
?>