<?php
ob_start();
session_start();
include 'conn.php';
if(isset($_POST['submit'])){
    $s = "SELECT * FROM admin where username='".$_POST['uname']."' and userpass='".$_POST['password']."' "; 
    $a=mysqli_query($conn,$s) or die(mysqli_error($conn));
    $n=mysqli_num_rows($a);
    if($n>0){
	$r=mysqli_fetch_array($a);  
	    $_SESSION['adminemail']=$r['email'];
        $_SESSION['idadmin']=$r['id'];
	    $_SESSION['username']=$r['username'];
    header("location:profile.php");
    }else{       // echo "wrong password" ;
	header("location:index.php?msg=Username or Password is Incorrect");
    }
    ob_flush();
}    
?>

