<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
	    $id=$_POST['id'];
	    $message=$_POST['message']; 
		$sql1= "UPDATE forum SET description='$message' WHERE id='$id'";   
		if( mysqli_query($conn,$sql1))
		{
			$res1= mysqli_query($conn,$sql1);
			
			if ($res1){ 
				header("Location:edit-message.php?id=$id&msg=2");
			}
		}else{
			header("Location:edit-message.php?id=$id&msg=1");
		}

    }
}
?>