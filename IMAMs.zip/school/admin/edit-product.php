<?php
session_start();
include "conn.php";
if(isset($_SESSION['idadmin']))
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="">
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <!--Loading bootstrap css-->
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="css/jquery-ui-1.10.4.custom.min.css">
    <link type="text/css" rel="stylesheet" href="css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">

    <!--LOADING STYLESHEET FOR PAGE-->
    <link type="text/css" rel="stylesheet" href="css/jquery.dataTables.css">
    <link type="text/css" rel="stylesheet" href="css/dataTables.tableTools.min.css">
    <link type="text/css" rel="stylesheet" href="css/dataTables.bootstrap.css">



    <!--Loading style vendors-->
    <link type="text/css" rel="stylesheet" href="css/animate.css">
    <link type="text/css" rel="stylesheet" href="css/pace.css">
    <link type="text/css" rel="stylesheet" href="css/all.css">
    <link type="text/css" rel="stylesheet" href="css/jquery.notific8.min.css">
    <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">

    <!--Loading style-->
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" class="default-style">
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" id="theme-change" class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="css/style-responsive.css">
    <style>
	.table select option {
		color: #000;
	}
	@media print
         {
         .noprint {display:none;}
         #print{display:inline-table!important; display:block!important;}
         }
         input[type='radio']{
         opacity: 1 !important;
         width: 150% !important;
         height: 15px !important;
         margin: 4px 0px !important;
         }     
	
	.print-only{
        display: none;
    }

    @media print {
        .no-print {
            display: none;
        }

        .print-only{
            display: block;
        }
}

    </style>
</head>
<body class="">
    <!--BEGIN BACK TO TOP-->
    <a class="noprint" id="totop" href="#"><i class="fa fa-angle-up"></i></a>
    <!--END BACK TO TOP-->
    <!--BEGIN TOPBAR-->
    <?php 
    include'include/header.php';
    ?>
    <!--END TOPBAR-->
    <div id="wrapper">
    <!--BEGIN SIDEBAR MENU-->
	<?php include'include/sidebar.php'; ?>
	<!--END SIDEBAR MENU-->
	<!--BEGIN PAGE WRAPPER-->
	<div id="page-wrapper">
	    <!--BEGIN TITLE & BREADCRUMB PAGE-->
	    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb noprint">
		<ol class="breadcrumb page-breadcrumb pull-left">
                    <li><i class="fa fa-home"></i>&nbsp;<a href="manage-product.php">Merchandise</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
		       <li class="hidden"><a href="#">Dashboard</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
		       <li class="active">Edit Merchandise</li>
		    </ol>
		   <a href="events.php"> <div class="btn btn-blue reportrange"><i class="fa fa-calendar"></i>&nbsp;<span></span></div></a>
		    <div class="clearfix"></div>
	    </div>
	    <div class="page-content">
		<div id="table-action" class="row">
		    <div class="col-lg-12">
			<?php
			if(isset($_GET['msg']))
			{
			    if($_GET['msg']==1)
			    {
			?>
			<div class="panel-heading">
			    <h2 align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Error </h2> 
			</div> 
			<?php
			    }
			    if($_GET['msg']==2)
			    {
			?>
			<div class="panel-heading">
			    <h2 align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Save Successfully</h2> 
			</div> 
			<?php
			    }
			}
			?>

			
			<div id="tableactionTabContent" class="tab-content">
			    <div id="pp" class="tab-pane fade in active">
				<div class="row">
				    <div class="col-lg-12">
					<div class="panel panel-blue">
					    <div class="panel-heading">Edit Product</div>
					    <div class="panel-body pan">
						<div class="panel-heading">
						    <h4 align="center" class="panel-title" style="color:#FF0000;"> </h4> 
						</div> 
						<?php 
						$idss = $_GET['id'];
						$sql="SELECT * FROM product WHERE id='$idss'";
						$res=mysqli_query($conn,$sql);
						$row=mysqli_fetch_assoc($res);		
//print_r($row);						
						?>						
                    <form action="edit-productdb.php" method="post" enctype="multipart/form-data"  id="" class="">  
						    <div class="row">
							<div class="form-group col-md-4">
							<label for="feature">Product Name : :</label>
							<input type="text" class="form-control" name="name"  value="<?php echo $row['title']; ?>">
							<input type="hidden" name="id" value="<?php echo $idss;?>">
							</div>
							<div class="form-group col-md-4">
								<label for="feature">Product Description:</label>
								<input type="text" class="form-control" placeholder="Enter Scholar Number" name="desc"  value="<?php echo $row['description']; ?>">
							</div>
							<div class="form-group col-md-4">
							    <label for="feature">Product Price:</label>
							    <input type="text" class="form-control" name="price"  value="<?php echo $row['price']; ?>">
							</div>
							<div class="form-group col-md-4">
							    <label for="feature">Product Size</label>
							    <input type="text" class="form-control" name="psize" value="<?php echo $row['psize']; ?>">
							</div>

							<div class="form-group col-md-4">
							    <label for="feature">Product Image:</label>
								<div class="p-image">
								<i class="fas fa-times-circle"></i>
								<?php if($row['img']!='') {?>
									<img src="upload/<?php echo $row['img'];?>" alt="" style="width:100px;height:100px;">
								<?php } else {?>
									<img src="images/profile.jpg" alt="" style="width:100px;height:100px;">
								<?php } ?>
								</div>
							</div>
						    
                                                    </div><br>
							<input type="submit" class="btn-primary btn btn-sm" name="submit" value="Save"> 
                                                        
						</form>
				

					    </div>
					</div>
				    </div>
				</div>
			    </div>
			</div>
		    </div>
		</div>
	    </div>
	</div>
	<!--BEGIN FOOTER-->
	<?php include'include/footer.php'?>
    </div>
    <script>
      $.validate({
	lang: 'es'
      });
    </script>

    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/jquery-ui.js"></script><!--loading bootstrap js-->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="js/jquery.metisMenu.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/icheck.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/jquery.notific8.min.js"></script>
    <script src="js/highcharts.js"></script>
    <script src="js/jquery.menu.js"></script>
    <script src="js/pace.min.js"></script>
    <script src="js/holder.js"></script>
    <script src="js/responsive-tabs.js"></script>
    <script src="js/jquery.newsTicker.min.js"></script>
    <script src="js/moment.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/daterangepicker.js"></script>
    <!--CORE JAVASCRIPT-->
    <script src="js/main.js"></script>
	<style>
	.p-image{
		position:relative;
	}
	.p-image i{
		position:absolute;
		color:red;
		font-size:20px;
		top:-10px;
		left:80px;
		display:none;
	}
	.p-image:hover i{ 
		  display:block;
		  cursor:pointer;
	}
	</style>
	<script>
$(document).ready(function(){
  $(".p-image i").click(function(){
    $(".p-image").empty();
	$(".p-image").html('<input type="file" name="image">');
  });
});
</script>
</body>
</html>
    <?php 
    } 
else
{
    header("location:index.php");
}
?>