<?php
session_start();
include "conn.php";
if(isset($_SESSION['idadmin']))
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="">
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <!--Loading bootstrap css-->
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="css/jquery-ui-1.10.4.custom.min.css">
    <link type="text/css" rel="stylesheet" href="css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">

    <!--LOADING STYLESHEET FOR PAGE-->
    <link type="text/css" rel="stylesheet" href="css/jquery.dataTables.css">
    <link type="text/css" rel="stylesheet" href="css/dataTables.tableTools.min.css">
    <link type="text/css" rel="stylesheet" href="css/dataTables.bootstrap.css">



    <!--Loading style vendors-->
    <link type="text/css" rel="stylesheet" href="css/animate.css">
    <link type="text/css" rel="stylesheet" href="css/pace.css">
    <link type="text/css" rel="stylesheet" href="css/all.css">
    <link type="text/css" rel="stylesheet" href="css/jquery.notific8.min.css">
    <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">

    <!--Loading style-->
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" class="default-style">
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" id="theme-change" class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="css/style-responsive.css">
    <style>
	.table select option {
		color: #000;
	}
	@media print
         {
         .noprint {display:none;}
         #print{display:inline-table!important; display:block!important;}
         }
         input[type='radio']{
         opacity: 1 !important;
         width: 150% !important;
         height: 15px !important;
         margin: 4px 0px !important;
         }     
	
	.print-only{
        display: none;
    }

    @media print {
        .no-print {
            display: none;
        }

        .print-only{
            display: block;
        }
}

    </style>
</head>
<body class="">
    <!--BEGIN BACK TO TOP-->
    <a class="noprint" id="totop" href="#"><i class="fa fa-angle-up"></i></a>
    <!--END BACK TO TOP-->
    <!--BEGIN TOPBAR-->
    <?php 
    include'include/header.php';
    ?>
    <!--END TOPBAR-->
    <div id="wrapper">
    <!--BEGIN SIDEBAR MENU-->
	<?php include'include/sidebar.php'; ?>
	<!--END SIDEBAR MENU-->
	<!--BEGIN PAGE WRAPPER-->
	<div id="page-wrapper">
	    <!--BEGIN TITLE & BREADCRUMB PAGE-->
	    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb noprint">
		<ol class="breadcrumb page-breadcrumb pull-left">
                    <li><i class="fa fa-home"></i>&nbsp;<a href="edit-schedule.php">Schedule</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
		       <li class="hidden"><a href="#">Dashboard</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
		       <li class="active">Edit Schedule</li>
                       </ol>
		     <a href="events.php"> <div class="btn btn-blue reportrange"><i class="fa fa-calendar"></i>&nbsp;<span></span></div></a>
		    <div class="clearfix"></div>
	    </div>
	    <!--END TITLE & BREADCRUMB PAGE-->
	    <!--BEGIN CONTENT-->
	    <div class="page-content">
		<div class="row">
		    <div class="col-lg-12">
			<div class="table-responsive">
			   
                            
                            <?php
			if(isset($_GET['msg']))
			{
			    if($_GET['msg']==1)
			    {
			?>
			<div class="panel-heading">
			    <h2 align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Error</h2> 
			</div> 
			<?php
			    }
			    if($_GET['msg']==2)
			    {
			?>
			<div class="panel-heading">
			    <h2 align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Edit Successfully</h2> 
			</div> 
			<?php
			    }
			}
			?>
                            
                            
                            
                            

			<div id="tableactionTabContent" class="tab-content">
			    <div id="pp" class="tab-pane fade in active">
				<div class="row">
				    <div class="col-lg-12">
					<div class="panel panel-blue">
					    <div class="panel-heading">Edit Schedule</div>
					    <div class="panel-body pan">
						<div class="panel-heading">
						    <h4 align="center" class="panel-title" style="color:#FF0000;"> </h4> 
						</div> 
						<?php 
						$tid = $_GET['id'];
						$sql="SELECT * FROM timetable WHERE id='$tid'";
						$res=mysqli_query($conn,$sql);
						$row=mysqli_fetch_assoc($res);		
//print_r($row);						
						?>						
                    <form action="edit-scheduledb.php" method="post" enctype="multipart/form-data"  id="contact_form"> 
                        <input type="hidden" name="id" value="<?php echo $tid;?>">
        
                                            <div class="form-group col-md-6">
              <label for="formGroupExampleInput">Master Name</label>
         <!-- <input type="text" class="form-control" name="MasterName" id="formGroupExampleInput" placeholder="Name" required>-->
    <select class="form-control" id="formGroupExampleInput"  name="MasterName" required>
          <option value="" disabled selected>Choose your option</option>
        <option value="Master Sen ">Master Sen </option>
        <option value="Master Vany">Master Vany</option>
        <option value="Master Ren">Master Ren</option>
        <option value="Master Mohan">Master Mohan</option>
        <option value="Master Rashid">Master Rashid</option>  
          </select>
        
        </div>
          <br>
        <div class="form-group col-md-6">
          <label for="formGroupExampleInput2">Location</label>
         <!--  <input type="text" class="form-control" name="SubjectName" id="formGroupExampleInput2" placeholder="Location" required>-->
       <select class="form-control" id="formGroupExampleInput2"  name="Location"  required>
          <option value="" disabled selected>Choose your option</option>
        <option value="Bukit Cheras (HQ) ">Bukit Cheras (HQ) </option>
        <option value="Cuepacs">Cuepacs</option>
        <option value="Sepang">Sepang</option>
        <option value="Jalan Ipoh">Jalan Ipoh</option>
        <option value="Kajang">Kajang</option>  
          </select>
        
        </div>
          <br>
        <div class="form-group col-md-6">
            
          <label for="formGroupExampleInput3">Ranking</label>
             <!-- <input type="text" class="form-control" name="ClassName" id="formGroupExampleInpu3" placeholder="Ranking" required>
        --> 
    <select class="form-control" id="formGroupExampleInput3"  name="Rank" required>
           <option value="" disabled selected>Choose your option</option>
        <option value="White Belt">White Belt</option>
        <option value="Blue Belt">Blue Belt</option>
        <option value="Yellow Belt">Yellow Belt</option>
        <option value="Green Belt">Green Belt</option>
        <option value="Purple Belt">Purple Belt</option>
                  <option value="Brown II">Brown II</option>
                   <option value="Brown I">Brown I</option>
                   <option value="Black Belt I Dan">Black Belt I Dan</option>
                   <option value="Black Belt II Dan">Black Belt II Dan</option>
                    <option value="Black Belt III Dan">Black Belt III Dan</option>
                    
          </select>
        </div>
          
      <div class="form-group col-md-6">
            
          <label for="formGroupExampleInput3">Day</label>
             <!-- <input type="text" class="form-control" name="ClassName" id="formGroupExampleInpu3" placeholder="Ranking" required>
        --> 
    <select class="form-control" id="formGroupExampleInput3"  name="Day" required>
           <option value="" disabled selected>Choose your option</option>
        <option value="Monday">Monday</option>
        <option value="Tuesday">Tuesday</option>
        <option value="Wednesday">Wednesday</option>
        <option value="Thursday">Thursday</option>
        <option value="Friday">Friday</option>
                  <option value="Saturday">Saturday</option>
                   <option value="Sunday">Sunday</option>
                       
          </select>
        </div>
          
          <br>
        <div class="form-group col-md-6">
          <label for="formGroupExampleInput4">Starting Time</label>
          <!-- comment  <input type="text" class="form-control" name="StartingTime" id="formGroupExampleInput4" placeholder="24:00:00" required> -->
        <input type="time" name="StartingTime" id="formGroupExampleInput4" name="appt"
       min="08:00" max="18:00" required>
        </div>
          <br>
        <div class="form-group col-md-6">
            <label for="formGroupExampleInput5">Ending Time </label>
          <!-- comment <input type="text" class="form-control" name="EndingTime" id="formGroupExampleInput5" placeholder="24:00:00" required>
         --> 
          <input type="time" name="EndingTime" id="formGroupExampleInput5" name="appt"
       min="08:00" max="18:00" required>
          
        </div>
          
          <br>
           
      
      
						    <input id="submit" type="submit" class="btn-primary btn btn-sm" name="submit" value="Submit"> 
						</form>

				

					    </div>
					</div>
				    </div>
				</div>
			    </div>
			</div>
		    </div>
		</div>
	    </div>
	</div>
	<!--BEGIN FOOTER-->
	<?php include'include/footer.php'?>
    </div>
    <script>
      $.validate({
	lang: 'es'
      });
    </script>

    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/jquery-ui.js"></script><!--loading bootstrap js-->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="js/jquery.metisMenu.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/icheck.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/jquery.notific8.min.js"></script>
    <script src="js/highcharts.js"></script>
    <script src="js/jquery.menu.js"></script>
    <script src="js/pace.min.js"></script>
    <script src="js/holder.js"></script>
    <script src="js/responsive-tabs.js"></script>
    <script src="js/jquery.newsTicker.min.js"></script>
    <script src="js/moment.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/daterangepicker.js"></script>
    <!--CORE JAVASCRIPT-->
    <script src="js/main.js"></script>
	<style>
	.p-image{
		position:relative;
	}
	.p-image i{
		position:absolute;
		color:red;
		font-size:20px;
		top:-10px;
		left:80px;
		display:none;
	}
	.p-image:hover i{ 
		  display:block;
		  cursor:pointer;
	}
	</style>
	<script>
$(document).ready(function(){
  $(".p-image i").click(function(){
    $(".p-image").empty();
	$(".p-image").html('<input type="file" name="image">');
  });
});
</script>
</body>
</html>
    <?php 
    } 
else
{
    header("location:index.php");
}
?>