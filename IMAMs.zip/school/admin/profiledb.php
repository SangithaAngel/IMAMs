<?php
ob_start();
include 'conn.php';
session_start();
if(isset($_POST['submit'])){
    $id=$_SESSION['idadmin'];
    $name=$_POST['name']; 
    $email=$_POST['email'];
    $sql="update admin set username='".$name."',email='".$email."' where id='".$id."'";
   
mysqli_query($conn,$sql) or die(mysqli_error());
header("location:profile.php");
ob_flush();   
}
?>  