<?php
session_start();
include "conn.php";
error_reporting();
if(isset($_SESSION['idadmin'])) 
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel</title>    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="">
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="images/favicon.png">

    <!--Loading bootstrap css-->
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="css/jquery-ui-1.10.4.custom.min.css">
    <link type="text/css" rel="stylesheet" href="css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">

    <!--LOADING STYLESHEET FOR PAGE-->
    <link type="text/css" rel="stylesheet" href="css/colorpicker.css">
    <link type="text/css" rel="stylesheet" href="css/datepicker.css">
    <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap-timepicker.min.css">
    <link type="text/css" rel="stylesheet" href="css/clockface.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap-switch.css">
    <link href="css/style-review.css" rel="stylesheet" type="text/css" />
    <link type="text/css" rel="stylesheet" href="css/bootstrap3-wysihtml5.min.css">

    <!--Loading style vendors-->
    <link type="text/css" rel="stylesheet" href="css/animate.css">
    <link type="text/css" rel="stylesheet" href="css/pace.css">
    <link type="text/css" rel="stylesheet" href="css/all.css">
    <link type="text/css" rel="stylesheet" href="css/jquery.notific8.min.css">
    <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">
	<link href='css/select2.css' rel='stylesheet' type='text/css'>

    <!--Loading style-->
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" class="default-style">
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" id="theme-change" class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="css/style-responsive.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <style>
	input[type='radio']{
	    opacity: 1 !important;
	    width: 150% !important;
	    height: 15px !important;
	    margin: 4px 0px !important;
	}     
    </style>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script> -->
</head>
<body class=" ">
    <a id="totop" href="#"><i class="fa fa-angle-up"></i></a>
    <?php include'include/header.php' ?>
    <div id="wrapper">
	<!--BEGIN SIDEBAR MENU-->
	<?php include'include/sidebar.php' ?>
	<!--END SIDEBAR MENU-->
	<!--BEGIN PAGE WRAPPER-->
	<div id="page-wrapper">
	    <!--BEGIN TITLE & BREADCRUMB PAGE-->
	    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
		<!--<div class="page-header pull-left"><div class="page-title">Publish News</div></div>-->
		<ol class="breadcrumb page-breadcrumb pull-left">
                    <li class="active"><i class="fa fa-home"></i>&nbsp;<a href="add-schedule.php">Schedule > Add Schedule </a></li>
		</ol>
		 <a href="events.php"> <div class="btn btn-blue reportrange"><i class="fa fa-calendar"></i>&nbsp;<span></span></div></a>
		<div class="clearfix"></div>
	    </div>
	    <div class="page-content">
		<div id="table-action" class="row">
		    <div class="col-lg-12">
			<?php
			if(isset($_GET['msg']))
			{
			    if($_GET['msg']==1)
			    {
			?>
			<div class="panel-heading">
			    <h2 align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Error</h2> 
			</div> 
			<?php
			    }
			    if($_GET['msg']==2)
			    {
			?>
			<div class="panel-heading">
			    <h2 align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Save Successfully</h2> 
			</div> 
			<?php
			    }
				if($_GET['msg']==3)
			    {
			?>
			<div class="panel-heading">
			    <h2 align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Fees Already Added.</h2> 
			</div> 
			<?php
			    }  
			}
			?>

			<div id="tableactionTabContent" class="tab-content">
			    <div id="pp" class="tab-pane fade in active">
				<div class="row">
				    <div class="col-lg-12">
					<div class="panel panel-blue">
					    <div class="panel-heading">Add Schedule</div>
					    <div class="panel-body pan">
						<div class="panel-heading">
						    <h4 align="center" class="panel-title" style="color:#FF0000;"> </h4> 
						</div> 
					
						
					<form action="add-scheduledb.php" method="post" enctype="multipart/form-data"  id="contact_form"> 
        <input type="hidden" id="id" name="id" value="">
                                            <div class="form-group col-md-6">
              <label for="formGroupExampleInput">Master Name</label>
         <!-- <input type="text" class="form-control" name="MasterName" id="formGroupExampleInput" placeholder="Name" required>-->
    <select class="form-control" id="formGroupExampleInput"  name="MasterName" required>
          <option value="" disabled selected>Choose your option</option>
        <option value="Master Sen ">Master Sen </option>
        <option value="Master Vany">Master Vany</option>
        <option value="Master Ren">Master Ren</option>
        <option value="Master Mohan">Master Mohan</option>
        <option value="Master Rashid">Master Rashid</option>  
          </select>
        
        </div>
          <br>
        <div class="form-group col-md-6">
          <label for="formGroupExampleInput2">Location</label>
         <!--  <input type="text" class="form-control" name="SubjectName" id="formGroupExampleInput2" placeholder="Location" required>-->
       <select class="form-control" id="formGroupExampleInput2"  name="Location"  required>
          <option value="" disabled selected>Choose your option</option>
        <option value="Bukit Cheras (HQ) ">Bukit Cheras (HQ) </option>
        <option value="Cuepacs">Cuepacs</option>
        <option value="Sepang">Sepang</option>
        <option value="Jalan Ipoh">Jalan Ipoh</option>
        <option value="Kajang">Kajang</option>  
          </select>
        
        </div>
          <br>
        <div class="form-group col-md-6">
            
          <label for="formGroupExampleInput3">Ranking</label>
             <!-- <input type="text" class="form-control" name="ClassName" id="formGroupExampleInpu3" placeholder="Ranking" required>
        --> 
    <select class="form-control" id="formGroupExampleInput3"  name="Rank" required>
           <option value="" disabled selected>Choose your option</option>
        <option value="White Belt">White Belt</option>
        <option value="Blue Belt">Blue Belt</option>
        <option value="Yellow Belt">Yellow Belt</option>
        <option value="Green Belt">Green Belt</option>
        <option value="Purple Belt">Purple Belt</option>
                  <option value="Brown II">Brown II</option>
                   <option value="Brown I">Brown I</option>
                   <option value="Black Belt I Dan">Black Belt I Dan</option>
                   <option value="Black Belt II Dan">Black Belt II Dan</option>
                    <option value="Black Belt III Dan">Black Belt III Dan</option>
                    
          </select>
        </div>
           <br>
        <div class="form-group col-md-6">
            
          <label for="formGroupExampleInput3">Day</label>
             <!-- <input type="text" class="form-control" name="ClassName" id="formGroupExampleInpu3" placeholder="Ranking" required>
        --> 
    <select class="form-control" id="formGroupExampleInput3"  name="Day" required>
           <option value="" disabled selected>Choose your option</option>
        <option value="Monday">Monday</option>
        <option value="Tuesday">Tuesday</option>
        <option value="Wednesday">Wednesday</option>
        <option value="Thursday">Thursday</option>
        <option value="Friday">Friday</option>
                  <option value="Saturday">Saturday</option>
                   <option value="Sunday">Sunday</option>
                       
          </select>
        </div>
          
          
          <br>
        <div class="form-group col-md-6">
          <label for="formGroupExampleInput4">Starting Time</label>
          <!-- comment  <input type="text" class="form-control" name="StartingTime" id="formGroupExampleInput4" placeholder="24:00:00" required> -->
        <input type="time" name="StartingTime" id="formGroupExampleInput4" name="appt"
       min="08:00" max="18:00" required>
        </div>
          <br>
        <div class="form-group col-md-6">
            <label for="formGroupExampleInput5">Ending Time </label>
          <!-- comment <input type="text" class="form-control" name="EndingTime" id="formGroupExampleInput5" placeholder="24:00:00" required>
         --> 
          <input type="time" name="EndingTime" id="formGroupExampleInput5" name="appt"
       min="08:00" max="18:00" required>
          
        </div>
          
          <br>
           
						    <input id="submit" type="submit" class="btn-primary btn btn-sm" name="submit" value="Submit"> 
						</form>

					    </div>
					</div>
				    </div>
				</div>
			    </div>
			</div>
		    </div>
		</div>
	    </div>
	</div>
	<!--BEGIN FOOTER-->
	<?php include'include/footer.php'?>
    </div>
    <script>
      $.validate({
	lang: 'es'
      });
    </script>

    <!--<script src="js/jquery-1.10.2.min.js"></script>-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/jquery-ui.js"></script><!--loading bootstrap js-->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="js/jquery.metisMenu.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/icheck.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/jquery.notific8.min.js"></script>
    <script src="js/highcharts.js"></script>
    <script src="js/jquery.menu.js"></script>
    <script src="js/pace.min.js"></script>
    <script src="js/holder.js"></script>
    <script src="js/responsive-tabs.js"></script>
    <script src="js/jquery.newsTicker.min.js"></script>
    <script src="js/moment.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/daterangepicker.js"></script>
	<script src='js/select2.js' type='text/javascript'></script>
    <!--CORE JAVASCRIPT-->
    <script src="js/main.js"></script>
	<script>
		$(document).ready(function(){
			$("#idcardno").select2();
			$("#idcardno").change(function(e){   	
				idcardno=$(this).val(); 
				if(idcardno != ""){
					console.log(idcardno); 
					$.ajax({
					  url: "ajax-add-fees.php",   
					  method: "POST",
					  data:  { idcardno: idcardno },
					  success: function(z){
						if(z=="false"){
							$('#branch').val("");
							$('#id').val("");
							$('#rank').val("");
						}else{
							var json = $.parseJSON(z);
							console.log(z);  
							$('#branch').val(json['branch']);
							$('#id').val(json['id']);
							$('#rank').val(json['rank']);
						}						
					  }
					});	  
				}else{  
					console.log("no value");       				
				}
			});
			
				//////////
		$("#submit").click(function(){
		 var idcardno=  $('#idcardno').val();		
		 var feetype=  $('#feetype').val();		
		 var totalfee= $('#totalfee').val();
		 var branch= $('#branch').val();
		 var rank= $('#rank').val();
		   if(idcardno=="")
		   { alert("SELECT Student Ic No");
	         		  return false;
	       }
		   if(feetype=="")
		   { alert("SELECT feetype");
	         		  return false;
	       }
		   if(totalfee=="")
		   { alert("Enter Fee");
	           return false;
	       }
		   	if(branch=="")
		   { alert("Enter branch");
	         	  return false;
	       }
		   	if(rank=="")
		   { alert("Enter rank");
	           return false;
	       }
		  return true;
		});	

		}); 

	</script>
</body>
</html>
<?php  
}  
else
{
    header("location:index.php");
}
?>