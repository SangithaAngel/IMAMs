<?php 
    session_start();
	//error_reporting('E_ALL');
    include "conn.php";  
	$tid = $_GET['id'];
	$sql="DELETE FROM timetable WHERE id='$tid'";         
		if (mysqli_query($conn,$sql)){ 
		    mysqli_query($conn,$sql);
			header("location:manage-schedule.php?msg=1");
		}else{
			echo "Error ".mysqli_error($conn); 
		}  
?>