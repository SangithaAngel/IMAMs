<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
	  $fid=$_POST['fid'];
	  $sid=$_POST['id'];
	  $date=$_POST['date']; 
	  $payment=$_POST['totalfee']; 
	  $branch=$_POST['branch']; 
	  $rank=$_POST['rank'];   
	  $feetype=$_POST['feetype'];   
          
      $sql="UPDATE fees SET studentid='$sid',date='$date',payment='$payment',feetype='$feetype' WHERE id='$fid'";  
	  
		if (mysqli_query($conn,$sql)){ 
		      mysqli_query($conn,$sql);  
			       $sql="SELECT * FROM student WHERE icno ='$sid'";
		     $result=mysqli_query($conn,$sql);		
			 $row=mysqli_fetch_assoc($result);
			 $email=$r['email_id'];
			 
			  	$email=$r['email_id'];
				$name=$r['name'];
				$subject= " Monthly Updated Fee:   Notification  ";
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";        
				$contactMessage =  
				"<div>
				<p><strong>Dear $name,</strong></p>
				<br/>
				<p>
				<strong>Date:</strong>$date <br/>
				<strong>FEE:</strong>$totalfee 
				</p>
				<br/>
				<p><strong>Thanks & Regards</strong></p><br/>
				</div>";
					
			$response = (mail($email,$subject,$contactMessage,$headers) ) ? 
			"success" : "failure" ;
			 header('location:add-fees.php?msg=2');
			  
			header('location:edit-fees.php?msg=2');
		}else{
			echo 'Error '.mysqli_error($conn);
			die();
			header('location:edit-fees.php?msg=1');    
		}
    }
}
?>