<?php 
    session_start();
	//error_reporting('E_ALL');
    include "conn.php";  
	$idss = $_GET['id'];
	$sql="DELETE FROM student WHERE id='$idss'";         
		if (mysqli_query($conn,$sql)){ 
		    mysqli_query($conn,$sql);
			header("location:manage-students.php?msg=1");
		}else{
			echo "Error ".mysqli_error($conn); 
		}  
?>