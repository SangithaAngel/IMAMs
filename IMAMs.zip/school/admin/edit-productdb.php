<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
	$id=$_POST['id'];
	$name=$_POST['name']; 
	$desc=$_POST['desc']; 
	$price=$_POST['price'];
	$psize=$_POST['psize'];
	//$status=$_POST['emstatus'];	
	if(isset($_FILES['image']))
	{
		$file_name = $_FILES['image']['name'];
		$file_size =$_FILES['image']['size'];
		$file_tmp =$_FILES['image']['tmp_name'];
		$file_type=$_FILES['image']['type'];
		$file_ext=explode('.',$file_name);
		$file_ext=strtolower(end($file_ext));
		$destination="../admin/upload/";
		if(($file_ext=='jpg')||($file_ext=='jpeg')||($file_ext=='png'))
		{
			$img=uniqid().$file_name;
			move_uploaded_file($file_tmp, $destination.$img); 
		}else{
			$img='';
		}
		$sql1= "UPDATE product SET title='$name',description='$desc',price='$price',psize='$psize',img='$img' WHERE id='$id'"; 
	}else{
		$sql1= "UPDATE product SET title='$name',description='$desc',price='$price',psize='$psize' WHERE id='$id'";   
	}
		if( mysqli_query($conn,$sql1))
		{
			$res1= mysqli_query($conn,$sql1);
			
			if ($res1){ 
				header("Location:edit-product.php?id=$id&msg=2");
			}
		}else{
             echo 'error '.mysqli_error($conn);
			 die();
			header("Location:edit-product.php?id=$id&msg=1");
		}
	    
	//}
    }
}
?>