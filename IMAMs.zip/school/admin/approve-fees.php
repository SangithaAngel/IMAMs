<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_GET['id']))
    {
		$fid=$_GET['id'];  
		$sql="UPDATE fees SET verification='approved' WHERE id='$fid'";  	  
		if (mysqli_query($conn,$sql)){ 	
		header('location:manage-fees.php?msg=2');
		}else{
		header('location:manage-fees.php?msg=1');    
		}
    }
}
?>