<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
	$icno=$_POST['icno'];
	$name=$_POST['name']; 
	$fname=$_POST['fname']; 
	$contct_number=$_POST['contct_number']; 
	$email_id=$_POST['email_id']; 
	$password=$_POST['password']; 
	$adds=$_POST['adds']; 
	$branch=$_POST['branch']; 
	$rank=$_POST['rank']; 

	//$status=$_POST['emstatus'];	
	$file_name = $_FILES['image']['name'];
	$file_size =$_FILES['image']['size'];
	$file_tmp =$_FILES['image']['tmp_name'];
	$file_type=$_FILES['image']['type'];
	$file_ext=explode('.',$file_name);
	$file_ext=strtolower(end($file_ext));
	$destination="upload/";
	if(($file_ext=='jpg')||($file_ext=='jpeg')||($file_ext=='png'))
	{
	    $img=uniqid().$file_name;
	    move_uploaded_file($file_tmp, $destination.$img);
	}else{
	    $img='';
	}
		$sql1= "INSERT INTO trainer (icno,name,fname,contct_number,email_id,pass,adds,branch,rank,img)VALUES('$icno','$name','$fname','$contct_number','$email_id','$password','$adds','$branch','$rank','$img')";        
	    $res1= mysqli_query($conn,$sql1);
		//echo("Errorcode: " . mysqli_errno($conn));
		if ($res1){ 
			header('location:add-trainer.php?msg=2');
		}else{
			header('location:add-trainer.php?msg=1');
		}
	    
	//}
    }
}
?>