<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
		$sid=$_POST['id'];
		 		
		 $date=$_POST['date']; 
		 $idcardno=$_POST['idcardno']; 
		 $totalfee=$_POST['totalfee'];
		 $branch=$_POST['branch'];
		 $rank=$_POST['rank']; 
		 $feetype=$_POST['feetype'];   
		 $year = date('Y', strtotime($date));
		 $month = date('m', strtotime($date));
		 //$month = 5;  
		/*  $sql="SELECT * FROM fees WHERE studentid='$sid' AND YEAR(date)='$year' AND MONTH(date)='$month'";

				 $result=mysqli_query($conn,$sql); 		 
				 if(mysqli_num_rows($result)>0)
				 { header('location:add-fees.php?msg=3');
					 die();
				 }   */
			
			 
		 
		if($sid!=""){
			  $sid.' '; 
		
			 $sql1= "INSERT INTO fees (studentid,date,branch,rank,payment,feetype) VALUES('$sid','$date','$branch','$rank','$totalfee','$feetype')";   
			
			if (mysqli_query($conn,$sql1)){ 
				 $sql2="SELECT * FROM student WHERE id ='$sid'";
				 $result2=mysqli_query($conn,$sql2);		
				 $r=mysqli_fetch_assoc($result2);
				   
				    $email=$r['email_id'];
					$name=$r['name'];
					$subject= "Monthly Fee Notification  ";
					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";        
					$contactMessage =  
					"<div>
					<p><strong>Dear $name,</strong></p>
					<br/>
					<p>
					<strong>Date:</strong>$date <br/>
					<strong>FEE:</strong>$totalfee 
					</p>
					<br/>
					<p><strong>Thanks & Regards</strong></p><br/>
					</div>";
						
				$response = (mail($email,$subject,$contactMessage,$headers) ) ? 
				"success" : "failure" ;

				 header('location:add-fees.php?msg=2');
				 
			}else{
				echo  "Error ".mysqli_error($conn);
				header('location:add-fees.php?msg=1');
			}
		}else{
			header('location:add-fees.php?msg=1');
				
		} 
    }
}
?>