<?php
session_start();
include "conn.php";
if(isset($_SESSION['idadmin'])) 
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel </title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="">
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="images/favicon.png">

    <!--Loading bootstrap css-->
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="css/jquery-ui-1.10.4.custom.min.css">
    <link type="text/css" rel="stylesheet" href="css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">

    <!--LOADING STYLESHEET FOR PAGE-->
    <link type="text/css" rel="stylesheet" href="css/colorpicker.css">
    <link type="text/css" rel="stylesheet" href="css/datepicker.css">
    <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap-timepicker.min.css">
    <link type="text/css" rel="stylesheet" href="css/clockface.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap-switch.css">
    <link href="css/style-review.css" rel="stylesheet" type="text/css" />
    <link type="text/css" rel="stylesheet" href="css/bootstrap3-wysihtml5.min.css">

    <!--Loading style vendors-->
    <link type="text/css" rel="stylesheet" href="css/animate.css">
    <link type="text/css" rel="stylesheet" href="css/pace.css">
    <link type="text/css" rel="stylesheet" href="css/all.css">
    <link type="text/css" rel="stylesheet" href="css/jquery.notific8.min.css">
    <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">

    <!--Loading style-->
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" class="default-style">
    <link type="text/css" rel="stylesheet" href="css/orange-blue.css" id="theme-change" class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="css/style-responsive.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <style>
	input[type='radio']{
	    opacity: 1 !important;
	    width: 150% !important;
	    height: 15px !important;
	    margin: 4px 0px !important;
	}     
    </style>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script> -->
</head>
<body class=" ">
    <a id="totop" href="#"><i class="fa fa-angle-up"></i></a>
    <?php include'include/header.php' ?>
    <div id="wrapper">
	<!--BEGIN SIDEBAR MENU-->
	<?php include'include/sidebar.php' ?>
	<!--END SIDEBAR MENU-->
	<!--BEGIN PAGE WRAPPER-->
	<div id="page-wrapper">
	    <!--BEGIN TITLE & BREADCRUMB PAGE-->
	    <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
		<!--<div class="page-header pull-left"><div class="page-title">Publish News</div></div>-->
		<ol class="breadcrumb page-breadcrumb pull-left">
                    <li class="active"><i class="fa fa-home"></i>&nbsp;<a href="add-message.php">Communication > Add Message</a></li>
		</ol>
                 <a href="events.php"> <div class="btn btn-blue reportrange"><i class="fa fa-calendar"></i>&nbsp;<span></span></div></a>
		
		<div class="clearfix"></div>
	    </div>
	    <div class="page-content">
		<div id="table-action" class="row">
		    <div class="col-lg-12">
			<?php
			if(isset($_GET['msg']))
			{
			    if($_GET['msg']==1)
			    {
			?>
			<div class="panel-heading">
			    <h2 align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Error</h2> 
			</div> 
			<?php
			    }
			    if($_GET['msg']==2)
			    {
			?>
			<div class="panel-heading">
			    <h2 align="center" class="panel-title" style="color:#FF0000;font-weight:bold;">Message sent</h2> 
			</div> 
			<?php
			    }
			}
			?>

			<div id="tableactionTabContent" class="tab-content">
			    <div id="pp" class="tab-pane fade in active">
				<div class="row">
				    <div class="col-lg-12">
					<div class="panel panel-blue">
					    <div class="panel-heading">Add Message</div>
					    <div class="panel-body pan">
						<div class="panel-heading">
						    <h4 align="center" class="panel-title" style="color:#FF0000;"> </h4> 
						</div> 
						<form action="add-messagedb.php" method="post" enctype="multipart/form-data" autocomplete="off" id="contact_form" onsubmit="return student_form()" name="contact_form"> 
						    <div class="row">
								<div class="form-group col-md-12">
									<label for="feature">Add Message:</label>
									<textarea  class="form-control" placeholder="Enter message" name="message"> </textarea>
								</div>
                                <div class="form-group col-md-12">				
						            <input type="submit" class="btn-primary btn btn-sm" name="submit" value="send"> 
							    </div>
						</form>
					    </div>
					</div>
				    </div>
				</div>
			    </div>
			</div>
		    </div>
		</div>
	    </div>
	</div>
	<!--BEGIN FOOTER-->
	<?php include'include/footer.php'?>
    </div>
    <script>
      $.validate({
	lang: 'es'
      });
    </script>

    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/jquery-ui.js"></script><!--loading bootstrap js-->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="js/jquery.metisMenu.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/icheck.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/jquery.notific8.min.js"></script>
    <script src="js/highcharts.js"></script>
    <script src="js/jquery.menu.js"></script>
    <script src="js/pace.min.js"></script>
    <script src="js/holder.js"></script>
    <script src="js/responsive-tabs.js"></script>
    <script src="js/jquery.newsTicker.min.js"></script>
    <script src="js/moment.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/daterangepicker.js"></script>
    <!--CORE JAVASCRIPT-->
    <script src="js/main.js"></script>
</body>
</html>
    <?php 
    } 
else
{
    header("location:index.php");
}
?>