<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
	$title=$_POST['title']; 
	$pdesc=$_POST['pdesc']; 
	$price=$_POST['price']; 
	$psize=$_POST['psize'];  

	//$status=$_POST['emstatus'];	
	$file_name = $_FILES['image']['name'];
	$file_size =$_FILES['image']['size'];
	$file_tmp =$_FILES['image']['tmp_name'];
	$file_type=$_FILES['image']['type'];
	$file_ext=explode('.',$file_name);
	$file_ext=strtolower(end($file_ext));
	$destination="upload/";
	if(($file_ext=='jpg')||($file_ext=='jpeg')||($file_ext=='png'))
	{
	    $img=uniqid().$file_name;
	    move_uploaded_file($file_tmp, $destination.$img);
	}else{
	    $img='';
	}
		$sql1="INSERT INTO product (title,description,price,psize,img)VALUES('$title','$pdesc','$price','$psize','$img')";          
	    $res1= mysqli_query($conn,$sql1);
		//echo("Errorcode: " . mysqli_errno($conn));
		if ($res1){ 
			header('location:add-product.php?msg=2');
		}else{
			header('location:add-product.php?msg=1');
		}
	    
	//}
    }
}
?>