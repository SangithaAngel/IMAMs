<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
  $tid=$_POST['id'];
  $mn = $_POST["MasterName"];
  $loc = $_POST["Location"];
  $rank = $_POST["Rank"];
   $day =$_POST["Day"];
  $st = $_POST["StartingTime"];
  $et = $_POST["EndingTime"];
	//$status=$_POST['emstatus'];	
    
	$sql1= "UPDATE timetable SET mn='$mn',loc='$loc',rank='$rank',day='$day', st='$st', et='$et' WHERE id='$tid'"; 	
       
	}
		if( mysqli_query($conn,$sql1))
		{
			$res1= mysqli_query($conn,$sql1);
			
			if ($res1){ 
				header("Location:edit-schedule.php?id=$id&msg=2");
			}
		}else{
             echo 'error '.mysqli_error($conn);
			 die();
			header("Location:edit-schedule.php?id=$id&msg=1");
		}
	    
	//}
    }

?>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    