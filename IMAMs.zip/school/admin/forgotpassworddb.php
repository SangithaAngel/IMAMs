<?php
include 'conn.php'; 
if(isset($_POST['submit']))
{
    $s="SELECT * FROM admin where email='".$_POST['email']."'"; 
//echo $s;
$a=mysqli_query($conn,$s);
$n=mysqli_num_rows($a);

if($n>0)
{
	$r=mysqli_fetch_array($a);
 	$email=$r['email'];
	$username=$r['username'];
	$password=$r['userpass'];
        $token=$r['token'];
	$subject= "Reset Password ";
        
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";      
    $link = "<a href='www.yourwebsite.com/reset-password.php?key=".$emailId."&token=".$token."'>Click To Reset password</a>";
 
    $contactMessage =  
	"<div>
	<p><strong>Dear $username,</strong></p>
	<br/>
	<p><strong>Reset Password </strong> </p> 
	<br/>
	<p>
	<strong>Username:</strong>$username <br/>
	<strong>Cureent Password:</strong>$password 
	</p>
	<br/>
	<p><strong>Thanks & Regards</strong></p><br/>
	<p><strong>Team IMAMS</strong></p><br/>
	</div>";
        
$response = (mail($email,$subject,$contactMessage,$headers) ) ? 
"success" : "failure" ;
	//$output = json_encode(array("response" => $response));
	header("location:forgot-password.php?msg=1");
}
else
{        
	 header("location:forgot-password.php?msg=0");
}
}

?>