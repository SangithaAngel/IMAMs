<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {

  $tid=$_POST['id'];
  $mn = $_POST["MasterName"];
  $loc = $_POST["Location"];
  $rank = $_POST["Rank"];
  $day =$_POST["Day"];
  $st = $_POST["StartingTime"];
  $et = $_POST["EndingTime"];
  //echo $tname." ".$sname." ".$cname." ".$st." ".$et;
  //echo "asdasdasdaasd";
  
  	
 $sql = "INSERT INTO timetable(id, mn, loc, rank,day ,st, et) VALUES ('$tid','$mn', '$loc', '$rank',$day, '$st', '$et')";
  if (mysqli_query($conn, $sql)) {
    echo "<script type='text/javascript'>
    alert('New record created successfully');
  </script>" ;
          
       
  } 
  else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}  }
?>
<?php
if(isset($_POST['submit']))
{
// Insert Query Put here

header('Location: add-schedule.php');
}

?>
