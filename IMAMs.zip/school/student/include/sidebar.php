<?php
	 $id=$_SESSION['idadmin'];
?>
    <nav id="sidebar" role="navigation" class="navbar-default navbar-static-side noprint">
        <div class="sidebar-collapse menu-scroll">
            <ul id="side-menu" class="nav">
                <li class="user-panel">
                    <div class="thumb">
                        <?php
                        $sqll="select * from student where id='".$id."'";
                        $resultl=mysqli_query($conn,$sqll);
                        $rowl=mysqli_fetch_array($resultl);
                        $image=$rowl['img'];
                        if($image!='') {
                        ?>
                        <img src="../admin/upload/<?php echo $image; ?>" alt="Profile" class="img-circle">
                        <?php } else { ?>
                         <img src="images/profile.jpg" alt="Profile" class="img-circle"/>
                        <?php } ?>
                    </div>
                    <div class="info"><p>Student: <?php  echo $rowl['name']?></p>
                        <ul class="list-inline list-unstyled">
                            <li><a href="profile.php" data-hover="tooltip" title="Profile"><i class="fa fa-user"></i></a></li>
                            <li><a href="logout.php" data-hover="tooltip" title="Logout"><i class="fa fa-sign-out"></i></a></li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                </li>
				<li>
                    <a href="profile.php"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title">Profile</span>
                    </a>
                </li>
				<li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title"> Attandance</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="scan.php"><span class="submenu-title">Add Attendance</span></a></li>
			<li><a href="view-attandance.php"><span class="submenu-title">View Attendance</span></a></li>
                    </ul> 
                </li>
				<li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title"> Fees</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="manage-fees.php"><span class="submenu-title">Manage Fees</span></a></li>
                    </ul> 
                </li>
                
                
                
                <li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title"> Schedule</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="manage-schedule.php"><span class="submenu-title">Manage Schedule</span></a></li>
                    </ul> 
                </li>
                
				<li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title"> Merchandise</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="manage-product.php"><span class="submenu-title">Shopping</span></a></li>
                    </ul> 
                </li>
				<li>
                    <a href="#"><i class="fa fa-file-text fa-fw"><div class="icon-bg bg-orange"></div></i>
                        <span class="menu-title"> Communication</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li><a href="add-message.php"><span class="submenu-title">Add Message</span></a></li>
						 <li><a href="manage-message.php"><span class="submenu-title">View Message</span></a></li>
                    </ul> 
                </li>
            </ul>
        </div>
    </nav>  