<?php
session_start();
include "conn.php";
if(isset($_SESSION['idadmin'])){
	 $id=$_SESSION['idadmin'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Student Panel | Profile </title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="cache-control" content="no-cache">
        <meta http-equiv="expires" content="">
        <link rel="shortcut icon" href="images/favicon.ico">
        <link rel="apple-touch-icon" href="images/favicon.png">
        <link rel="apple-touch-icon" href="images/favicon.png">
        <link rel="apple-touch-icon" href="images/favicon.png">

        <!--Loading bootstrap css-->
        <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
        <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
        <link type="text/css" rel="stylesheet" href="css/jquery-ui-1.10.4.custom.min.css">
        <link type="text/css" rel="stylesheet" href="css/font-awesome.min.css">
        <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">

        <!--LOADING STYLESHEET FOR PAGE-->
        <link type="text/css" rel="stylesheet" href="css/bootstrap-markdown.min.css">
        <link type="text/css" rel="stylesheet" href="css/bootstrap3-wysihtml5.min.css">
        <link type="text/css" rel="stylesheet" href="css/summernote.css">

        <!--Loading style vendors-->
        <link type="text/css" rel="stylesheet" href="css/animate.css">
        <link type="text/css" rel="stylesheet" href="css/pace.css">
        <link type="text/css" rel="stylesheet" href="css/all.css">
        <link type="text/css" rel="stylesheet" href="css/css/style.css">
        <link type="text/css" rel="stylesheet" href="css/jquery.notific8.min.css">
        <link type="text/css" rel="stylesheet" href="css/daterangepicker-bs3.css">

        <!--Loading style-->
        <link type="text/css" rel="stylesheet" href="css/orange-blue.css" class="default-style">
        <link type="text/css" rel="stylesheet" href="css/orange-blue.css" id="theme-change" class="style-change color-change">
        <link type="text/css" rel="stylesheet" href="css/style-responsive.css">
        <style>
            @media print{
                .noprint {display:none;}
                #print{display:inline-table!important; display:block!important;}
            }
        </style>
		
    </head>

    <body class="">
        <!--BEGIN BACK TO TOP-->
        <a class="noprint" id="totop" href="#"><i class="fa fa-angle-up"></i></a>
        <!--END BACK TO TOP-->

        <!--BEGIN TOPBAR-->
        <?php 
        include'include/header.php'
        ?><!--END TOPBAR-->
        <div id="wrapper">
            <!--BEGIN SIDEBAR MENU-->
			
            <?php include'include/sidebar.php' ?><!--END SIDEBAR MENU-->

            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb noprint">
                    <ol class="breadcrumb page-breadcrumb pull-left">
                           <li><i class="fa fa-home"></i>&nbsp;<a href="profile.php">Profile</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                           <li class="hidden"><a href="#">Dashboard</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                     </ol>
                     <	<a href="events.php"> <div class="btn btn-blue reportrange"><i class="fa fa-calendar"></i>&nbsp;<span></span></div></a>
                        <div class="clearfix"></div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="table-action" class="row">
                        <div class="col-lg-12">
                            <div id="tableactionTabContent" class="tab-content">
                                <div id="pp" class="tab-pane fade in active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="panel panel-blue">
                                               <div class="panel-heading">Profile</div>
                                               <div class="panel-body">
                                                    <tbody>
                                                    <?php 
													$sql="SELECT * FROM student WHERE id='$id'";
													$result=mysqli_query($conn,$sql);
													while($row=mysqli_fetch_assoc($result))
													{
                                      ?>
                                                        <form action="profiledb.php" method="post" class="form-horizontal form-bordered" enctype="multipart/form-data" name="formlogin" onSubmit="return profile();">
<div  class="form-body">
		<div class="col-md-6"> 
			<div class="form-group">    
				   <label for="inputFirstName" class=" control-label"> Profile Image </label>  
					<div class="p-image">
					<i class="fa fa-times-circle"></i>
					<?php if($row['img']!='') {?>
					<img src="../admin/upload/<?php echo $row['img'];?>" alt="" style="width:100px;height:100px;">
					<?php } else {?>
					<img src="images/profile.jpg" alt="" style="width:100px;height:100px;">
					<?php } ?>
					</div>
			</div> 
		</div>
		<div class="col-md-6">
			<div class="form-group">
				<h5><b>First Name  </b> </h5>
				<p><?php echo $row['name'];?> </p>	
			</div> 
		</div>
		<div class="col-md-6">  
			<div class="form-group"> 
				 <h5><b>Last Name  </b> </h5>
				 <p><?php echo $row['fname'];?></p>	
			</div> 
		</div>  
		<div class="col-md-6">  
			<div class="form-group">    
				<h5><b>Email </b> </h5>
				 <p><?php echo $row['email_id'];?> </p>
			</div> 
		</div>
		<div class="col-md-6">  
			<div class="form-group">    
				<h5><b>Contact Number</b> </h5>
				<p><?php echo $row['contct_number'];?> </p>
			</div> 
		</div>
		<div class="col-md-6">  
			<div class="form-group">    
				 <h5><b>Address  </b> </h5>
				 <p><?php echo $row['adds'];?> </p>	
			</div> 
		</div>
		<div class="col-md-6">  
			<div class="form-group">    
				 <h5><b>Branch</b> </h5>
				 <p><?php echo $row['branch'];?> </p>	
			</div> 
		</div>
		<div class="col-md-6">  
			<div class="form-group">    
				 <h5><b>Rank</b> </h5>
				 <p><?php echo $row['rank'];?> </p>	
			</div> 
		</div>
		<div class="form-actions text-right pal"> 
           <a class="btn btn-primary" href="edit-profile.php">	Edit </a>	

		</div>
</div>
</form>
<?php
}												
?>

                                                    </tbody>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--END CONTENT-->
                    </div>
                    <!--END PAGE WRAPPER-->

                    <!--BEGIN FOOTER-->
                   <?php include'include/footer.php'?>
                    <!--END FOOTER-->

                    <!--END  WRAPPER-->
                </div>
            </div>
        </div>
        <script src="js/jquery-1.10.2.min.js"></script>
        <script src="js/jquery-migrate-1.2.1.min.js"></script>
        <script src="js/jquery-ui.js"></script><!--loading bootstrap js-->
        <script src="js/bootstrap.min.js"></script>
        <script src="js/bootstrap-hover-dropdown.js"></script>
        <script src="js/html5shiv.js"></script>
        <script src="js/respond.min.js"></script>
        <script src="js/jquery.metisMenu.js"></script>
        <script src="js/jquery.slimscroll.js"></script>
        <script src="js/jquery.cookie.js"></script>
        <script src="js/icheck.min.js"></script>
        <script src="js/custom.min.js"></script>
        <script src="js/jquery.notific8.min.js"></script>
        <script src="js/highcharts.js"></script>
        <script src="js/jquery.menu.js"></script>
        <script src="js/pace.min.js"></script>
        <script src="js/holder.js"></script>
        <script src="js/responsive-tabs.js"></script>
        <script src="js/jquery.newsTicker.min.js"></script>
        <script src="js/moment.js"></script>
        <script src="js/bootstrap-datepicker.js"></script>
        <script src="js/daterangepicker.js"></script>
        <!--CORE JAVASCRIPT-->
        <script src="js/main.js"></script>
        <!--LOADING SCRIPTS FOR PAGE-->
        <script src="jsjs/bootstrap-markdown.js"></script>
        <script src="js/bootstrap3-wysihtml5.all.min.js"></script>
        <script src="js/ckeditor.js"></script>
        <script src="js/summernote.js"></script>
        <script src="js/ui-editors.js"></script>
        <!-- <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script type="text/javascript" src="tableExport.js"></script>
        <script type="text/javascript" src="jquery.base64.js"></script> -->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
       
		<style>
	.p-image{
		position:relative;
	}
	.p-image i{
		position:absolute;
		color:red;
		font-size:20px;
		top:0px;
		left:90px;
		display:none;
	}
	/*
	.p-image:hover i{ 
		  display:block;
		  cursor:pointer;
	}*/   
	</style>
	<script>
$(document).ready(function(){
  $(".p-image i").click(function(){
    $(".p-image").empty();
	$(".p-image").html('<input type="file" name="image">');
  });
});
</script>
    </body>
</html>
<?php 
}else{
    header("location:index.php"); 
}
?>