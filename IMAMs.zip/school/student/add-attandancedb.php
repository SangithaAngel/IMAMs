<?php
session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
{ 
    if(isset($_POST['submit']))
    {
   	 $stid=$_SESSION['idadmin'];
	 $branch=$_POST['branch']; 
	 $rank=$_POST['rank']; 
	 $sesid=$_POST['id']; 
	 $date=$_POST['date']; 
	$stime=$_POST['stime']; 
		$sql="SELECT * FROM tr_attandance WHERE branch='$branch' AND id='$sesid' AND date='$date' ";
		$result=mysqli_query($conn,$sql);
		$rowcount=mysqli_num_rows($result);
		if($rowcount==1)
		{
                    
    $sesid = $_POST['sessid'];
    $branch = $_POST['branch']; // receive the text for QR
    $date = $_POST['date']; // receive the text for QR
    $stime = $_POST['stime']; // receive the text for QR
    $etime = $_POST['etime']; // receive the text for QR
    $rank = $_POST['rank']; // receive the text for QR 
	$tid=$_SESSION['idadmin'];
	
		  $sql1= "INSERT INTO st_attandance (sessid,sid,branch,rank,date,time)VALUES('$sesid','$stid','$branch','$rank','$date','$stime')";          
			$res1= mysqli_query($conn,$sql1);
			if ($res1){ 
				header('location:add-attandance.php?msg=2');
			}else{
				header('location:add-attandance.php?msg=1');
			}
		}else{
			header('location:add-attandance.php?msg=3');
		}
    }
}
?>