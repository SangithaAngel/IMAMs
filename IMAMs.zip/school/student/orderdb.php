<?php
ob_start();
include 'conn.php';
session_start();
if(isset($_POST['submit'])){
     $payment=$_POST['payment'];	
     $uid=$_SESSION['idadmin'];	
	 $paymode=$_POST['paymode'];
	 $recieptid=$_POST['recieptid'];
	 $usertype='student';
	 $sql1= "INSERT INTO orders(userid,payment,paymode,usertype,recieptid)VALUES('$uid','$payment','$paymode','$usertype','$recieptid')";
    if(mysqli_query($conn,$sql1))
	{		 
          $last_id = mysqli_insert_id($conn);
        header("location:order-thankyou.php?id=".$last_id);  
	}else{
		     header("location:manage-order.php");  
	}
ob_flush();   
}
?>  