 <?php
 session_start();
//error_reporting('E_ALL');
include "conn.php";
if(isset($_SESSION['idadmin']))
if (isset($_POST['result']) == 'result')
{
    $sesid = $_POST['sessid'];
    $branch = $_POST['branch']; // receive the text for QR
    $date = $_POST['date']; // receive the text for QR
    $stime = $_POST['stime']; // receive the text for QR
    $etime = $_POST['etime']; // receive the text for QR
    $rank = $_POST['rank']; // receive the text for QR 
	$tid=$_SESSION['idadmin'];
	
 
	$sql1= "INSERT INTO st_attandance (sessid,branch,rank,startdate,enddate,date)VALUES('$tid','$branch','$rank','$stime','$etime','$date')";          
    $res1=  mysqli_query($conn,$sql1);      
			if ($res1){ 
				header('location:view-attandance.php?msg=2');
			}else{
				header('location:view-attandance.php?msg=1');
			}
		}else{
			header('location:scan1.php?msg=3');
		}

?>