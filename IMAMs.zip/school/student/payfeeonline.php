<?php
session_start();
include "conn.php";
error_reporting();
if(isset($_SESSION['idadmin']))
{

if(isset($_POST['paysubmit'])){
	  $id=$_POST['id'];	
	 $paymode=$_POST['paymode'];
	 $date=$_POST['date'];	
	 $amount=$_POST['amount'];	
	 $referenceid=$_POST['referenceid'];	
	 $bank=isset($_POST['bank'])?$_POST['bank']:'';	

		  if(!empty($_FILES['image']['name']))
		 {
			$file_name = $_FILES['image']['name'];
			$file_size =$_FILES['image']['size'];
			$file_tmp =$_FILES['image']['tmp_name'];
			$file_type=$_FILES['image']['type'];
			$file_ext=explode('.',$file_name);
			$file_ext=strtolower(end($file_ext));
			$destination="../admin/upload/";
		    if(($file_ext=='jpg')||($file_ext=='jpeg')||($file_ext=='png'))
		   {
			    $img=uniqid().$file_name;
			    move_uploaded_file($file_tmp, $destination.$img); 
			    
		   }else{
			$img='';
		   }
		 }
		$sql1= "UPDATE fees SET status='paid',subdate='$date',paymentway='$paymode',verification='pending',Screenshot='$img',bankname='$bank',referenceid='$referenceid' WHERE id='$id'";
		if(mysqli_query($conn,$sql1))
		{	header("location:thankyou.php?id=".$id);    
		}else{		
			 header("location:pay-fees.php?msg=1&id=".$id);     		
		}
}





}
else
{
    header("location:index.php");
}
?>