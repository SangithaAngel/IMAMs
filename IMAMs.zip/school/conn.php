<?php
$host="localhost";
$username="root";
$password="";
$db="school";     
$conn=mysqli_connect($host,$username,$password,$db);
if(!$conn)
{ echo "Connection Not  created successfully.".mysqli_connect_error($conn);
}
?>